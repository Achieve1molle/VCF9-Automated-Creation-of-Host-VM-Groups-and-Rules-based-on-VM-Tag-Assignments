# VCF9 AZ Placement Automation - Example CSV Files

These example CSVs match the expected inputs for the VCF9 AZ Placement Automation UI script.

## Files

1. tags-bootstrap.csv
   - Optional. Use only when the UI option to create/bootstrap tags and categories is selected.

2. inventory-tag-assignments.csv
   - Required for tag-only mode and full DRS automation mode.
   - Assigns tags to inventory objects such as Hosts, VMs, Datastores, and Distributed Switches.

3. inventory-tag-assignments-multiple-tags-example.csv
   - Optional example showing how to assign multiple tags to the same object using TagCategory1/Tag1, TagCategory2/Tag2, etc.

4. hosts-drs-groups.csv
   - Required only when Run DRS Automation is enabled.
   - Creates/updates DRS host groups based on hosts with the specified tag.

5. vms-drs-groups-and-rules.csv
   - Required only when Run DRS Automation is enabled.
   - Creates/updates DRS VM groups based on VMs with the specified tag.
   - Creates/updates VM-to-Host DRS rules linking VM groups to host groups.

## Replace sample values

Before running, replace these placeholders with values from your environment:

- vcsa01.lab.local
- Cluster-A
- esxi-a01.lab.local, esxi-a02.lab.local, esxi-b01.lab.local, esxi-b02.lab.local
- app01, app02, db01, db02
- vsanDatastore-AZ1
- VDS-AZ1

## Usage modes

Tag-only mode:
- inventory-tag-assignments.csv only
- Optional: tags-bootstrap.csv if creating tags/categories first

Full DRS automation mode:
- inventory-tag-assignments.csv
- hosts-drs-groups.csv
- vms-drs-groups-and-rules.csv
- Optional: tags-bootstrap.csv if creating tags/categories first
